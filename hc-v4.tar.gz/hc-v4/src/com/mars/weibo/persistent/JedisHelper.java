package com.mars.weibo.persistent;
/**
 * 将userid和对应的url放到redis数据库中
 * @author hoot
 *
 */
public class JedisHelper {

}
