package com.mars.weibo.persistent;

import java.io.IOException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.HttpClient;
import org.json.JSONException;

import com.mars.weibo.login.FeedUtils;
import com.mars.weibo.login.WeiboLogin;
import com.mars.weibo.model.WeiboMsg;

public class PersistentWeiboMsg {
	private static final Log logger = LogFactory.getLog(PersistentWeiboMsg.class);
	public static void main(String[] args) throws JSONException, IOException {
		FeedUtils utils = new FeedUtils();
		HttpClient client = WeiboLogin.getLoginStatus();
        
        String personalUrl = "http://weibo.com/humingchun?wvr=5&lf=reg";

        List<WeiboMsg> homeMsgs = utils.getHomeWeiboMsgs(client, personalUrl);
         //将每次爬取到的url读加入数据库，下次从数据库取出url，结合bloomfilter来判断是否爬取过，
        //如果重启后，则要将爬取过的url来初始化bloomfilter
        
        
         //接下来从上面获取的信息里进行爬取
        //for()遍历
        String url = "http://weibo.com/chansaint";
        List<WeiboMsg> msgs = utils.getPersonalPageWeibo(client, url, "1502560603");
        logger.info("personal size" + msgs.size());
	}
}
