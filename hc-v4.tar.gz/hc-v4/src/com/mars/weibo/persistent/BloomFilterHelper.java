package com.mars.weibo.persistent;

import com.skjegstad.utils.BloomFilter;

/**
 * 将
 * @author hoot
 *
 */
public class BloomFilterHelper {
	private BloomFilter<String> bloomFilter;
	
	public BloomFilterHelper() {
		// TODO Auto-generated constructor stub
		bloomFilter = new BloomFilter<String>(0.1, 4 * 100000000);//4亿个页面
	}
}
