package com.mars.weibo.persistent;
/**
 * 将微薄信息存到数据库中
 * @author hoot
 *
 */
public class MongoDBHelper {

}
