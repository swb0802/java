package com.mars.weibo.model;


public class PreLoginInfo {
	public long servertime;
	public String nonce;
	public String pubkey;
	public String pcid;
	public int retcode;
	public String rsakv;
	
	
}
