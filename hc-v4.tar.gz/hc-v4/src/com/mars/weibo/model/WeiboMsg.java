package com.mars.weibo.model;

import java.util.List;

public class WeiboMsg {
	private String WBName;
	
	private String WBMsg;
	private String userCard;
	private String userPageUrl;
	private List<UserInfo> atedUsers;
	
	public String getWBName() {
		return WBName;
	}
	public void setWBName(String wBName) {
		WBName = wBName;
	}
	public String getWBMsg() {
		return WBMsg;
	}
	public void setWBMsg(String wBMsg) {
		WBMsg = wBMsg;
	}
	public String getUserCard() {
		return userCard;
	}
	public void setUserCard(String userCard) {
		this.userCard = userCard;
	}
	public String getUserPageUrl() {
		return userPageUrl;
	}
	public void setUserPageUrl(String userPageUrl) {
		this.userPageUrl = userPageUrl;
	}
    public List<UserInfo> getAtedUsers() {
        return atedUsers;
    }
    public void setAtedUsers(List<UserInfo> atedUsers) {
        this.atedUsers = atedUsers;
    }

}
