package com.mars.weibo.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.mars.weibo.model.UserInfo;
import com.mars.weibo.model.WeiboMsg;
/**
 * 第一次以个人主页url抓取网页，分析后调用相应的接口，接口返回的是json
 * @author hoot
 *
 */
public class ParseFeed {

	private static final Log logger = LogFactory.getLog(ParseFeed.class);

	/**
	 * javascript中的正则STK.pageletM.view({"pid":"pl_content_homeFeed"开头,
	 * 以})</script>结尾,中间可以是任何字符串
	 */
	public static final String contentRegx = "<script>STK && STK.pageletM && STK.pageletM.view\\("
			+ "(\\{\"pid\":\"pl_content_homeFeed\"[\\s\\S]*?)" + "\\)</script>";

	/**
	 * 接受从response中读取的html，去除\/之类的字符，返回json中的html数据
	 * @param rawHTML
	 * @param pid json的一个值，代表页面是首页还是个人主页还是别人的主页
	 * @return
	 * @throws JSONException
	 */
	private String getNormalHTMLDataFromResponse(String rawHTML, String pid) {
		String contentRegx = "<script>STK && STK.pageletM && STK.pageletM.view\\("
				+ "(\\{\"pid\":\"" + pid + "\"[\\s\\S]*?)"
				+ "\\)</script>";
		Pattern pattern = Pattern.compile(contentRegx);
		Matcher matcher = pattern.matcher(rawHTML);
		String htmlData = "";
		if (matcher.find()) {
		    String htmlJson = matcher.group(1);
			JSONObject jsonObject;
			try {
				jsonObject = new JSONObject(htmlJson.replace("\\/", "/"));
				htmlData = jsonObject.getString("html");
			} catch (JSONException e) {
				logger.error("JsonExctption", e);
			}
			
		}
		return htmlData;
	}
	/**
	 * 接受从response中读取的html，去除\/之类的字符，返回html字符串
	 * @param rawHTML
	 * @return 首页的html数据
	 * @throws JSONException
	 */
	public String getHomeNormalHTMLData(String rawHTML) {
		String personId = "pl_content_homeFeed";
		return getNormalHTMLDataFromResponse(rawHTML, personId);
	}
	
	/**
	 * 接受从response中读取的html，去除\/之类的字符，返回html字符串
	 * @param rawHTML
	 * @return 我的个人主页的html数据
	 * @throws JSONException
	 */
	public String getMyNormalHTMLData(String rawHtml) throws JSONException{
		String personId = "pl_profile_myInfo";
		return getNormalHTMLDataFromResponse(rawHtml, personId);
	}
	
	
	/**
	 * 获取他人微薄content html数据
	 * 接受从response中读取的html，去除\/之类的字符，返回html字符串
	 * @param rawHTML
	 * @return 我的个人主页的html数据
	 * @throws JSONException
	 */
	public String getOtherNormalHTMLData(String rawHtml) throws JSONException{
		String personId = "pl_content_hisFeed";
		return getNormalHTMLDataFromResponse(rawHtml, personId);
	}
	
	/**
	 * 通过jsoup来解析微博数量
	 * @param normalHtml
	 * @return
	 * @throws JSONException 
	 */
	public int parseFeedCount(String rawHtmlResponse) throws JSONException {
	   //从response中获取包含微博条数的html
	    String personId = "pl_profile_photo";
        String normalHtml = getNormalHTMLDataFromResponse(rawHtmlResponse, personId);
	    
        //jsop解析微博条数
		Document document = Jsoup.parse(normalHtml, "http://weibo.com");
		
		Elements elements = document.select("strong[node-type=weibo]");
		if(elements.size() == 1){
			String weiboCount = elements.first().text();
			int count = Integer.parseInt(weiboCount);
			//logger.info("weiboCount：" + count);
			return count;
		}
		return -1;
	}
	
	
	/**
	 * 从首页数据中获取到最大的微薄id
	 * 
	 * @param htmlString
	 * @return
	 */
	public long getMaxWeiboId(String htmlString) {
		Document doc = Jsoup.parse(htmlString);
		//获取所有带有mid=digital 的节点
		Elements elements = doc.select("div[mid~=\\d+]");
		
		List<Long> mids = new ArrayList<Long>();
		for(Element element : elements){
			String mid = element.attr("mid");
			mids.add(Long.parseLong(mid));
		}
		
		return getMax(mids);
	}
	/**
	 * 从微博的Content Element中获取到最大的微薄id
	 * @param elements
	 * @return
	 */
	public long getMaxWeiboId(Elements elements) {        
        List<Long> mids = new ArrayList<Long>();
        for(Element element : elements){
            String mid = element.attr("mid");
            mids.add(Long.parseLong(mid));
        }
        
        return getMax(mids);
    }
	
	private Long getMax(List<Long> maxIds){
	    Long maxId = -1L;
        if(maxIds.size() >= 1){
            Collections.sort(maxIds);
            maxId = maxIds.get(maxIds.size() - 1);
        }
        
        return maxId;
	}
	/**
	 * 根据weiboContentElements 解析出有用的weibo数据
	 * 首页得到的发送或者被转发用户usercard形如usercard=id=11113423
	 * 被at用户的usercard形如 usercard=name=humingchun
	 * @param longHTMLStr
	 * @throws JSONException
	 * @throws ParserConfigurationException
	 * @throws XPathExpressionException
	 * @throws IOException
	 * @throws SAXException
	 */
	public List<WeiboMsg> parseHomeFeedFromElements(Elements weiboContentElements)
			throws JSONException, IOException {
		List<WeiboMsg> msgs = new ArrayList<WeiboMsg>();		

		logger.info(weiboContentElements.size());
		// 每个Element代表一条微薄，Element里面可能有转发的数目
		for (Element e : weiboContentElements) {
			WeiboMsg msg = new WeiboMsg();

			Elements nickElems = e.select("a[class~=WB_name S_func[13]]");
			if(nickElems == null || nickElems.size() == 0){
				return msgs;
			}
			
			Elements contentElements = e.select("div.WB_text");
			for (int i = 0; i < nickElems.size(); i++) {
				Element e1 = nickElems.get(i);
				//首页获得的usercard=id=234444
				msg.setUserCard(e1.attr("usercard").split("=")[1]);
				msg.setWBName(e1.text());
				msg.setUserPageUrl(e1.absUrl("href"));
				// if(contentElements.size() > 0 && i < contentElements.size()){
				Element wbElem = contentElements.get(i);
				msg.setWBMsg(wbElem.text());
				// }
				msgs.add(msg);
				logger.info(msg.getWBName() + " usercard:" + msg.getUserCard()
						 + " txt:" + msg.getWBMsg());
			}
		}
		return msgs;
	}

	/**
	 * 获取个人主页微博数据 
	 * 从feed_list_item节点获得数据
	 * @param element
	 * @return
	 */
	public List<WeiboMsg> parsePersonalWeibo(Elements elements){
	    List<WeiboMsg> msgs = new ArrayList<WeiboMsg>();   
	    for(Element element : elements){
	        WeiboMsg msg = new WeiboMsg();
	        //个人发送的微博
	       Element e = element.select("[node-type=feed_list_content]").first();
	       if(e == null){
	           logger.info(element.html());
	           return msgs;
	       }
	       msg.setWBMsg(e.text());
	       
	       //被at的user，没有id只有name
	       List<UserInfo> atedUsers = new ArrayList<UserInfo>();
	       Elements userElements = e.select("a[usercard]");
	       for(Element ue : userElements){
	           UserInfo userInfo = new UserInfo();
	           userInfo.setNickName(ue.attr("usercard").split("=")[1]);
	           userInfo.setHomeUrl(ue.attr("href"));
	           atedUsers.add(userInfo);
	           
	           logger.info("ated user:" + userInfo.getNickName());
	       }
	       msg.setAtedUsers(atedUsers);
	       msgs.add(msg);
	       
	       //转发他人的微博
	       Elements forward = element.select("div[node-type=feed_list_forwardContent]");
	       if(forward != null && forward.size() > 0){
	           Element nickElem = forward.select("a[node-type=feed_list_originNick]").first();
	           if(nickElem == null){
	               logger.info(forward.html());
	               //
	               break;
	           }
	           //被转发的微博
	           WeiboMsg forwardMsg = new WeiboMsg();
	           forwardMsg.setWBName(nickElem.text().replace("@", ""));
	           forwardMsg.setUserPageUrl(nickElem.attr("href"));
	           forwardMsg.setUserCard(nickElem.attr("usercard").split("=")[1]);
	           
	           //被转发的微博实际内容
	           String forwardContent = element.select("div.WB_text").first().text();
	           forwardMsg.setWBMsg(forwardContent);
	           msgs.add(forwardMsg);
	           logger.info("xx forwarded:" + forwardMsg);
	       }
           
	    }
	    return msgs;
	}
	/**
	 * 返回包含weibo内容的Elements
	 * @param longHTMLStr
	 * @return
	 */
	public Elements getWeiboContentElements(String longHTMLStr) {
		// File input = new File("src/weibo_data.html");
		Document doc = Jsoup.parse(longHTMLStr, "http://weibo.com");
		// 获取微薄数目，每条是
		Elements divElement = doc
				.select("div[action-type=feed_list_item]");//"div[diss-data=group_source=group_all]"
		//logger.info(divElement.size());
		return divElement;
	}
	
}
