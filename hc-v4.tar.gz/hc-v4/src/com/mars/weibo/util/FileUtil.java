package com.mars.weibo.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FileUtil {
	private static final Log logger = LogFactory.getLog(FileUtil.class);

	public static String getUname(){
		InputStream in = FileUtil.class
				.getResourceAsStream("/account.properties");
		Properties p = new Properties();
		try {
			p.load(in);
			// logger.info(p.get(key));
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return null;
		}
		
		return (String) p.get("uname");
	}

	public static String getPwd(){
		InputStream in = FileUtil.class
				.getResourceAsStream("/account.properties");
		Properties p = new Properties();
		try {
			p.load(in);
			// logger.info(p.get(key));
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return null;
		}
		
		return (String) p.get("pwd");
	}

	public static boolean saveToFile(String string, String filename,
			String contentEncoding) {
		FileOutputStream fo;
		try {
			fo = new FileOutputStream(new File(filename));
			fo.write(string.getBytes(contentEncoding));
			fo.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

		return true;
	}
}
