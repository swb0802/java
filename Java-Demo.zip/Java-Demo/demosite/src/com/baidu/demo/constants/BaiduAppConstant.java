/**
 * Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
 */
package com.baidu.demo.constants;


/**
 * 
 * @author chenhetong(chenhetong@baidu.com)
 *
 */
public class BaiduAppConstant {
    
    public static final String CLIENTID = "6kGc4XVQ8u6M40muw2dREeXm" ;
    
    public static final String CLIENTSECRET="HlnbG4OL3VakN3VoVfsWKfWatl9iADbv";
    
    public static final String REDIRECTURI = "http://127.0.0.1:8080/demosite/callback";
    
}
